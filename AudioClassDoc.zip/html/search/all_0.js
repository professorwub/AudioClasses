var searchData=
[
  ['addground_0',['addground',['../class_m_pnetwork.html#afef6117fb29f9ce9f86b5b39f08c8fa9',1,'MPnetwork']]],
  ['addjunctions_1',['addJunctions',['../class_m_pnetwork.html#a8139397ca4d5be07b6bbf12f5ed25d2c',1,'MPnetwork']]],
  ['addsource_2',['addsource',['../class_m_pnetwork.html#a221c6ce6b0af99ba5be836bd6c019295',1,'MPnetwork']]],
  ['addwaveguides_3',['addWaveguides',['../class_m_pnetwork.html#a99947106c80eecb75a452967429f99ba',1,'MPnetwork']]]
];
