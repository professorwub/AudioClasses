var searchData=
[
  ['update_37',['update',['../class_b_qfilter.html#abaa7191a3e9afc4da7b480d0378a2d7f',1,'BQfilter']]],
  ['updatesection_38',['updateSection',['../class_s_o_sfilter.html#a0be6d4871c98ef97f041446631444ca9',1,'SOSfilter']]]
];
