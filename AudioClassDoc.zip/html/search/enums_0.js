var searchData=
[
  ['filtertype_83',['FilterType',['../_b_qfilter_8h.html#a7ef0ab496f57e183b484e62e2053c94f',1,'BQfilter.h']]]
];
