var searchData=
[
  ['bqfilter_40',['BQfilter',['../class_b_qfilter.html',1,'']]]
];
