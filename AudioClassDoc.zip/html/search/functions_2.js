var searchData=
[
  ['freqresp_56',['freqresp',['../class_b_qfilter.html#a81d8a995074aa3886ca1025737b4878e',1,'BQfilter']]],
  ['freqresponse_57',['freqResponse',['../class_s_o_sfilter.html#a9f7550f58790e4bca654d85edcccc998',1,'SOSfilter']]]
];
