var searchData=
[
  ['initsos_64',['initsos',['../class_s_o_sfilter.html#ada47c2d4b5a67bf402fb62b0bac5823f',1,'SOSfilter']]]
];
