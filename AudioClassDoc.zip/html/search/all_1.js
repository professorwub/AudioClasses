var searchData=
[
  ['bqfilter_4',['BQfilter',['../class_b_qfilter.html',1,'']]]
];
