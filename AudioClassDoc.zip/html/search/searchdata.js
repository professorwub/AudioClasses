var indexSectionsWithContent =
{
  0: "abcdfgijlmnrsuw",
  1: "bdjlmrsw",
  2: "acfginrsu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

